package koolitus.REST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaRakendusApplicationTests {

	@Test
	void contextLoads() {
	}

}
